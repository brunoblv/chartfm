"use client";

import { useState, useEffect, useCallback } from "react";
import { useIsMobile } from "@/hooks/useIsMobile";
import type { CSSProperties } from "react";

// ─── Types ───────────────────────────────────────────────────────────────────

type Stage = "submission" | "waiting" | "listening" | "ranking" | "results";
type ResultTab = "round" | "season" | "geral";
type StreamingPlatform = "spotify" | "youtube";

interface Song {
  id: number;
  title: string;
  artist: string;
  album: string;
  rel: string;
  sid: string;
  sname: string;
  color: string;
}

interface Member {
  id: string;
  name: string;
  done: boolean;
}

interface RoundResult {
  rank: number;
  sid: number;
  pts: number;
}

interface OverallEntry {
  pos: number;
  name: string;
  pts: number;
  rounds: number;
  me: boolean;
}

// ─── Static demo data ────────────────────────────────────────────────────────

const SONGS: Song[] = [
  { id: 1,  title: "TEXAS HOLD EM",       artist: "Beyoncé",               album: "Cowboy Carter",        rel: "Mar 2025", sid: "u1",  sname: "Mariana", color: "#7C3AED" },
  { id: 2,  title: "Not Like Us",          artist: "Kendrick Lamar",        album: "GNX",                  rel: "Nov 2024", sid: "u2",  sname: "Pedro",   color: "#1D4ED8" },
  { id: 3,  title: "APT.",                 artist: "ROSÉ & Bruno Mars",     album: "Rosie",                rel: "Nov 2024", sid: "u3",  sname: "Ana",     color: "#BE185D" },
  { id: 4,  title: "Die With A Smile",     artist: "Lady Gaga & Bruno Mars",album: "Single",               rel: "Ago 2024", sid: "u4",  sname: "Carlos",  color: "#0F766E" },
  { id: 5,  title: "Espresso",             artist: "Sabrina Carpenter",     album: "Short n Sweet",        rel: "Abr 2025", sid: "me",  sname: "Você",    color: "#B45309" },
  { id: 6,  title: "Good Luck, Babe!",     artist: "Chappell Roan",         album: "The Rise and Fall…",   rel: "Abr 2025", sid: "u6",  sname: "Felipe",  color: "#0369A1" },
  { id: 7,  title: "A Bar Song (Tipsy)",   artist: "Shaboozey",             album: "Where I Come From",    rel: "Jun 2025", sid: "u7",  sname: "Roberta", color: "#15803D" },
  { id: 8,  title: "Please Please Please", artist: "Sabrina Carpenter",     album: "Short n Sweet",        rel: "Jun 2025", sid: "u8",  sname: "Lucas",   color: "#9D174D" },
  { id: 9,  title: "Lose Control",         artist: "Teddy Swims",           album: "I've Tried Everything",rel: "Fev 2025", sid: "u9",  sname: "Camila",  color: "#92400E" },
  { id: 10, title: "Harlequin",            artist: "Lady Gaga",             album: "Harlequin",            rel: "Set 2024", sid: "u10", sname: "Rafael",  color: "#1E3A5F" },
];

const MEMBERS: Member[] = [
  { id: "u1",  name: "Mariana R.", done: true  },
  { id: "u2",  name: "Pedro S.",   done: true  },
  { id: "u3",  name: "Ana C.",     done: true  },
  { id: "u4",  name: "Carlos M.",  done: true  },
  { id: "me",  name: "Você",       done: true  },
  { id: "u6",  name: "Felipe R.",  done: false },
  { id: "u7",  name: "Roberta L.", done: false },
  { id: "u8",  name: "Lucas B.",   done: false },
  { id: "u9",  name: "Camila F.",  done: true  },
  { id: "u10", name: "Rafael D.",  done: true  },
];

const RESULTS: RoundResult[] = [
  { rank: 1, sid: 1,  pts: 87 }, { rank: 2, sid: 3,  pts: 79 }, { rank: 3, sid: 5,  pts: 71 },
  { rank: 4, sid: 6,  pts: 63 }, { rank: 5, sid: 2,  pts: 58 }, { rank: 6, sid: 7,  pts: 52 },
  { rank: 7, sid: 4,  pts: 44 }, { rank: 8, sid: 8,  pts: 38 }, { rank: 9, sid: 9,  pts: 29 },
  { rank: 10, sid: 10, pts: 18 },
];

const OVERALL: OverallEntry[] = [
  { pos: 1, name: "Mariana R.", pts: 487, rounds: 12, me: false },
  { pos: 2, name: "Ana C.",     pts: 432, rounds: 12, me: false },
  { pos: 3, name: "Pedro S.",   pts: 398, rounds: 11, me: false },
  { pos: 4, name: "Você",       pts: 371, rounds: 12, me: true  },
  { pos: 5, name: "Felipe R.",  pts: 352, rounds: 10, me: false },
  { pos: 6, name: "Carlos M.",  pts: 318, rounds: 11, me: false },
  { pos: 7, name: "Roberta L.", pts: 295, rounds: 10, me: false },
  { pos: 8, name: "Lucas B.",   pts: 271, rounds: 9,  me: false },
];

const DEMO_SEARCH = [
  { id: "sr1", title: "Fortnight",        artist: "Taylor Swift ft. Post Malone", rel: "Abr 2025", color: "#4C1D95", valid: true  },
  { id: "sr2", title: "Birds of a Feather", artist: "Billie Eilish",              rel: "Mai 2025", color: "#064E3B", valid: true  },
  { id: "sr3", title: "Shake It Off",     artist: "Taylor Swift",                 rel: "Out 2014", color: "#D97706", valid: false },
];

const PODIUM_COLORS = ["#FFD700", "#C0C0C0", "#CD7F32"];
const MY_SONG = SONGS.find((s) => s.sid === "me")!;

const STAGES = ["Inscrição", "Revelação", "Escuta", "Avaliação", "Resultado"] as const;

const STAGE_INDEX: Record<Stage, number> = {
  submission: 0, waiting: 1, listening: 2, ranking: 3, results: 4,
};

const STAGE_LABEL: Record<Stage, string> = {
  submission: "Inscrição", waiting: "Aguardando", listening: "Escuta",
  ranking: "Avaliação", results: "Resultado",
};

const STAGE_TIME: Record<Stage, string> = {
  submission: "14h 23m restantes", waiting: "Inscrições encerradas",
  listening: "2d 11h restantes", ranking: "23h 14m restantes", results: "Rodada encerrada",
};

// ─── Shared atoms ────────────────────────────────────────────────────────────

function SongCover({ song, size = 40, radius = 8 }: { song: Song; size?: number; radius?: number }) {
  return (
    <div
      style={{
        width: size, height: size, borderRadius: radius, flexShrink: 0,
        background: song.color, display: "flex", alignItems: "center",
        justifyContent: "center", color: "rgba(255,255,255,.9)",
        fontSize: Math.floor(size * 0.38), fontWeight: 800,
      }}
    >
      {song.title[0].toUpperCase()}
    </div>
  );
}

function RankBadge({ n, active = false }: { n: number; active?: boolean }) {
  const podiumColor = n <= 3 ? PODIUM_COLORS[n - 1] : null;
  return (
    <div
      style={{
        width: 26, height: 26, borderRadius: 7, flexShrink: 0,
        display: "flex", alignItems: "center", justifyContent: "center",
        fontSize: 11, fontWeight: 800,
        background: active ? "var(--accent)" : podiumColor ?? "var(--fill-subtle)",
        color: active || podiumColor ? "white" : "var(--text-muted)",
      }}
    >
      {n}
    </div>
  );
}

function MiniAvatar({ name, size = 32 }: { name: string; size?: number }) {
  const hue = Math.abs(name.split("").reduce((a, c) => (a * 31 + c.charCodeAt(0)) | 0, 0)) % 360;
  return (
    <div
      style={{
        width: size, height: size, borderRadius: size / 2, flexShrink: 0,
        background: `hsl(${hue},42%,52%)`,
        display: "flex", alignItems: "center", justifyContent: "center",
        color: "white", fontSize: Math.floor(size * 0.4), fontWeight: 700,
      }}
    >
      {name[0].toUpperCase()}
    </div>
  );
}

function CheckIcon({ color = "white", size = 10 }: { color?: string; size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
      stroke={color} strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 6L9 17l-5-5" />
    </svg>
  );
}

function StageBar({ activeIndex }: { activeIndex: number }) {
  return (
    <div style={{ display: "flex", alignItems: "center" }}>
      {STAGES.flatMap((label, i) => {
        const done = i < activeIndex;
        const cur  = i === activeIndex;
        const dot  = (
          <div key={"d" + i} style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: 3, flexShrink: 0 }}>
            <div style={{ width: 7, height: 7, borderRadius: 4, background: done || cur ? "var(--accent)" : "var(--text-disabled)" }} />
            <div style={{ fontSize: 8, fontWeight: 600, whiteSpace: "nowrap", color: done || cur ? "var(--accent)" : "var(--text-muted)" }}>
              {label}
            </div>
          </div>
        );
        if (i < STAGES.length - 1) {
          return [dot, <div key={"l" + i} style={{ flex: 1, height: 1, background: done ? "var(--accent)" : "var(--text-disabled)", marginBottom: 11 }} />];
        }
        return [dot];
      })}
    </div>
  );
}

// ─── Screen 1 — Submission ───────────────────────────────────────────────────

function SubmissionScreen({
  submitted, onSubmit, onClear,
}: {
  submitted: boolean;
  onSubmit: () => void;
  onClear: () => void;
}) {
  const [q, setQ] = useState("");

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>

      {submitted ? (
        /* Confirmed song */
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: ".07em", textTransform: "uppercase", color: "var(--text-muted)", marginBottom: 8 }}>
            Sua indicação
          </div>
          <div style={{ background: "var(--surface)", border: "1.5px solid color-mix(in srgb, var(--accent) 28%, transparent)", borderRadius: 14, padding: 13, display: "flex", alignItems: "center", gap: 11 }}>
            <SongCover song={MY_SONG} size={46} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                {MY_SONG.title}
              </div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>
                {MY_SONG.artist} · {MY_SONG.album}
              </div>
              <div style={{ fontSize: 10, color: "#1DB954", fontWeight: 600, marginTop: 4, display: "flex", alignItems: "center", gap: 4 }}>
                <CheckIcon color="#1DB954" size={9} />
                Lançada em {MY_SONG.rel} · Válida
              </div>
            </div>
            <button
              type="button"
              onClick={onClear}
              style={{ background: "none", border: "none", color: "var(--text-muted)", cursor: "pointer", fontSize: 11, padding: "4px 8px", fontFamily: "inherit" }}
            >
              Trocar
            </button>
          </div>
        </div>
      ) : (
        /* Search */
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: ".07em", textTransform: "uppercase", color: "var(--text-muted)", marginBottom: 8 }}>
            Indique sua música
          </div>
          <div style={{ background: "color-mix(in srgb, var(--accent) 6%, transparent)", border: "1px solid color-mix(in srgb, var(--accent) 18%, transparent)", borderRadius: 11, padding: "9px 13px", fontSize: 12, color: "var(--text-muted)", lineHeight: 1.5, marginBottom: 12 }}>
            <span style={{ color: "var(--accent)", fontWeight: 700 }}>Regras: </span>
            Lançamento máx. 12 meses (data do álbum). Música não pode ter sido indicada em rodadas anteriores.
          </div>
          <div style={{ position: "relative", marginBottom: 10 }}>
            <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" strokeWidth={2.2} strokeLinecap="round"
              style={{ position: "absolute", left: 13, top: "50%", transform: "translateY(-50%)", pointerEvents: "none" }}>
              <circle cx={11} cy={11} r={7} /><path d="m21 21-4.3-4.3" />
            </svg>
            <input
              type="text"
              placeholder="Buscar no Spotify…"
              value={q}
              onChange={(e) => setQ(e.target.value)}
              style={{ width: "100%", padding: "11px 14px 11px 38px", borderRadius: 12, border: "1px solid var(--divider)", background: "var(--surface)", fontSize: 14, color: "var(--text)", outline: "none", boxSizing: "border-box", fontFamily: "inherit" }}
            />
          </div>
          {q.length > 0 && (
            <div style={{ background: "var(--surface)", border: "1px solid var(--divider)", borderRadius: 13, overflow: "hidden" }}>
              {DEMO_SEARCH.map((sr, i) => (
                <div
                  key={sr.id}
                  onClick={sr.valid ? onSubmit : undefined}
                  style={{ display: "flex", alignItems: "center", gap: 11, padding: "11px 14px", borderBottom: i < DEMO_SEARCH.length - 1 ? "1px solid var(--divider)" : "none", cursor: sr.valid ? "pointer" : "default", opacity: sr.valid ? 1 : 0.55 }}
                >
                  <div style={{ width: 42, height: 42, borderRadius: 7, background: sr.color, flexShrink: 0, display: "flex", alignItems: "center", justifyContent: "center", color: "rgba(255,255,255,.9)", fontSize: 16, fontWeight: 800 }}>
                    {sr.title[0]}
                  </div>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 13, fontWeight: 600, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{sr.title}</div>
                    <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>{sr.artist} · {sr.rel}</div>
                  </div>
                  {sr.valid
                    ? <span style={{ padding: "2px 7px", borderRadius: 100, background: "rgba(29,185,84,.12)", color: "#1DB954", fontSize: 10, fontWeight: 700, flexShrink: 0 }}>Válida</span>
                    : <span style={{ padding: "2px 7px", borderRadius: 100, background: "color-mix(in srgb, var(--accent) 10%, transparent)", color: "var(--accent)", fontSize: 10, fontWeight: 700, flexShrink: 0 }}>+1 ano</span>
                  }
                </div>
              ))}
            </div>
          )}
        </div>
      )}

      {/* Participants */}
      <div>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 8 }}>
          <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: ".07em", textTransform: "uppercase", color: "var(--text-muted)" }}>
            Participantes
          </span>
          <span style={{ fontSize: 11, color: "var(--text-muted)" }}>
            {MEMBERS.filter((m) => m.done).length}/{MEMBERS.length} indicaram
          </span>
        </div>
        <div style={{ display: "flex", flexWrap: "wrap", gap: 5 }}>
          {MEMBERS.map((m) => (
            <div
              key={m.id}
              style={{ display: "flex", alignItems: "center", gap: 4, padding: "4px 9px 4px 5px", borderRadius: 100, background: m.done ? "color-mix(in srgb, var(--accent) 10%, transparent)" : "var(--fill-subtle)", border: `1px solid ${m.done ? "color-mix(in srgb, var(--accent) 22%, transparent)" : "var(--divider)"}` }}
            >
              <div style={{ width: 15, height: 15, borderRadius: 7.5, background: m.done ? "var(--accent)" : "var(--text-disabled)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                {m.done && <CheckIcon size={7} />}
              </div>
              <span style={{ fontSize: 11, fontWeight: 600, color: m.done ? "var(--text)" : "var(--text-muted)" }}>
                {m.id === "me" ? "Você" : m.name.split(" ")[0]}
              </span>
            </div>
          ))}
        </div>
      </div>

      {!submitted && (
        <button
          type="button"
          onClick={onSubmit}
          style={{ padding: "14px", borderRadius: 14, border: "none", background: "var(--accent)", color: "white", fontSize: 15, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}
        >
          Confirmar indicação
        </button>
      )}
    </div>
  );
}

// ─── Screen 2 — Waiting ──────────────────────────────────────────────────────

function WaitingScreen() {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      <div style={{ background: "var(--surface)", border: "1.5px solid color-mix(in srgb, var(--accent) 22%, transparent)", borderRadius: 14, padding: 13, display: "flex", alignItems: "center", gap: 11 }}>
        <SongCover song={MY_SONG} size={46} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 10, fontWeight: 700, color: "var(--accent)", letterSpacing: ".06em", textTransform: "uppercase", marginBottom: 3 }}>Sua indicação</div>
          <div style={{ fontSize: 14, fontWeight: 700, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{MY_SONG.title}</div>
          <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>{MY_SONG.artist}</div>
        </div>
        <div style={{ width: 22, height: 22, borderRadius: 11, background: "#1DB954", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
          <CheckIcon color="white" size={11} />
        </div>
      </div>

      <div style={{ background: "color-mix(in srgb, var(--accent) 7%, transparent)", border: "1px solid color-mix(in srgb, var(--accent) 18%, transparent)", borderRadius: 16, padding: 20, textAlign: "center" }}>
        <div style={{ fontSize: 10, fontWeight: 700, color: "var(--accent)", letterSpacing: ".07em", textTransform: "uppercase", marginBottom: 8 }}>Revelação em</div>
        <div style={{ fontSize: 46, fontWeight: 900, color: "var(--text)", letterSpacing: "-.04em", fontVariantNumeric: "tabular-nums", lineHeight: 1 }}>09:41:22</div>
        <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 8 }}>Todas as músicas são reveladas simultaneamente</div>
      </div>

      <div>
        <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 12 }}>
          <span style={{ fontSize: 11, fontWeight: 700, letterSpacing: ".07em", textTransform: "uppercase", color: "var(--text-muted)" }}>Músicas da rodada</span>
          <span style={{ padding: "2px 8px", borderRadius: 100, background: "var(--fill-subtle)", color: "var(--text-muted)", fontSize: 11, fontWeight: 700 }}>10 músicas</span>
        </div>
        <div style={{ display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: 8 }}>
          {Array.from({ length: 10 }, (_, i) => (
            <div key={i} style={{ aspectRatio: "1", background: "var(--surface)", border: "1px solid var(--divider)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center" }}>
              <svg width={18} height={18} viewBox="0 0 24 24" fill="none" stroke="var(--text-disabled)" strokeWidth={1.8} strokeLinecap="round">
                <rect x={3} y={11} width={18} height={11} rx={2} /><path d="M7 11V7a5 5 0 0 1 10 0v4" />
              </svg>
            </div>
          ))}
        </div>
      </div>

      <div style={{ background: "var(--surface)", border: "1px solid var(--divider)", borderRadius: 12, padding: "13px 16px", display: "flex", alignItems: "center", gap: 10 }}>
        <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="var(--text-muted)" strokeWidth={2} strokeLinecap="round">
          <circle cx={12} cy={12} r={10} /><line x1={12} y1={8} x2={12} y2={12} /><line x1={12} y1={16} x2={12.01} y2={16} />
        </svg>
        <div style={{ fontSize: 12, color: "var(--text-muted)", lineHeight: 1.5 }}>
          Prepare-se! Após a revelação você terá 48h para ouvir todas as músicas antes de votar.
        </div>
      </div>
    </div>
  );
}

// ─── Screen 3 — Listening (Spotify + YouTube) ────────────────────────────────

const SPOTIFY_SVG_PATH = "M12 0C5.4 0 0 5.4 0 12s5.4 12 12 12 12-5.4 12-12S18.66 0 12 0zm5.521 17.34c-.24.359-.66.48-1.021.24-2.82-1.74-6.36-2.101-10.561-1.141-.418.122-.779-.179-.899-.539-.12-.421.18-.78.54-.9 4.56-1.021 8.52-.6 11.64 1.32.42.18.479.659.301 1.02zm1.44-3.3c-.301.42-.841.6-1.262.3-3.239-1.98-8.159-2.58-11.939-1.38-.479.12-1.02-.12-1.14-.6-.12-.48.12-1.021.6-1.141C9.6 9.9 15 10.561 18.72 12.84c.361.181.54.78.241 1.2zm.12-3.36C15.24 8.4 8.82 8.16 5.16 9.301c-.6.179-1.2-.181-1.38-.721-.18-.601.18-1.2.72-1.381 4.26-1.26 11.28-1.02 15.721 1.621.539.3.719 1.02.419 1.56-.299.421-1.02.599-1.559.3z";

function ListeningScreen() {
  const [platform, setPlatform] = useState<StreamingPlatform>("spotify");

  const tabBtnStyle = (active: boolean): CSSProperties => ({
    flex: 1,
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 7,
    padding: "10px 14px",
    borderRadius: 10,
    border: "none",
    fontSize: 13,
    fontWeight: 700,
    cursor: "pointer",
    fontFamily: "inherit",
    background: active ? "var(--surface)" : "transparent",
    color: active ? "var(--text)" : "var(--text-muted)",
    boxShadow: active ? "0 1px 3px rgba(0,0,0,.1)" : "none",
    transition: "all 150ms",
  });

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
      {/* Platform picker */}
      <div style={{ background: "var(--fill-subtle)", borderRadius: 13, padding: 3, display: "flex", gap: 3 }}>
        <button type="button" onClick={() => setPlatform("spotify")} style={tabBtnStyle(platform === "spotify")}>
          <svg width={14} height={14} viewBox="0 0 24 24" fill={platform === "spotify" ? "#1DB954" : "var(--text-muted)"}>
            <path d={SPOTIFY_SVG_PATH} />
          </svg>
          Spotify
        </button>
        <button type="button" onClick={() => setPlatform("youtube")} style={tabBtnStyle(platform === "youtube")}>
          <svg width={16} height={12} viewBox="0 0 24 18" fill={platform === "youtube" ? "#FF0000" : "var(--text-muted)"}>
            <path d="M23.495 2.205a3.02 3.02 0 0 0-2.122-2.138C19.505 0 12 0 12 0S4.495 0 2.627.07a3.02 3.02 0 0 0-2.122 2.138C0 4.07 0 8.123 0 8.123s0 4.052.505 5.917a3.02 3.02 0 0 0 2.122 2.138C4.495 16.246 12 16.246 12 16.246s7.505 0 9.373-.07a3.02 3.02 0 0 0 2.122-2.138C24 12.175 24 8.123 24 8.123s0-4.052-.505-5.918zM9.546 11.56V4.686l6.273 3.437-6.273 3.437z" />
          </svg>
          YouTube
        </button>
      </div>

      {/* Spotify card */}
      {platform === "spotify" && (
        <div style={{ background: "#121212", borderRadius: 16, padding: 16, display: "flex", flexDirection: "column", gap: 13 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 38, height: 38, borderRadius: 8, background: "#1DB954", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <svg width={22} height={22} viewBox="0 0 24 24" fill="white"><path d={SPOTIFY_SVG_PATH} /></svg>
            </div>
            <div>
              <div style={{ color: "#fff", fontSize: 14, fontWeight: 700 }}>Push — Rodada #12</div>
              <div style={{ color: "#B3B3B3", fontSize: 11, marginTop: 2 }}>10 músicas · 38 min</div>
            </div>
          </div>
          <button
            type="button"
            style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 7, padding: 11, borderRadius: 100, background: "#1DB954", color: "#000", fontSize: 13, fontWeight: 700, border: "none", cursor: "pointer", fontFamily: "inherit" }}
          >
            <svg width={15} height={15} viewBox="0 0 24 24" fill="#000"><path d={SPOTIFY_SVG_PATH} /></svg>
            Abrir no Spotify
          </button>
        </div>
      )}

      {/* YouTube card */}
      {platform === "youtube" && (
        <div style={{ background: "#0F0F0F", borderRadius: 16, padding: 16, display: "flex", flexDirection: "column", gap: 13 }}>
          <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
            <div style={{ width: 38, height: 38, borderRadius: 8, background: "#FF0000", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <svg width={20} height={16} viewBox="0 0 24 18" fill="white">
                <path d="M23.495 2.205a3.02 3.02 0 0 0-2.122-2.138C19.505 0 12 0 12 0S4.495 0 2.627.07a3.02 3.02 0 0 0-2.122 2.138C0 4.07 0 8.123 0 8.123s0 4.052.505 5.917a3.02 3.02 0 0 0 2.122 2.138C4.495 16.246 12 16.246 12 16.246s7.505 0 9.373-.07a3.02 3.02 0 0 0 2.122-2.138C24 12.175 24 8.123 24 8.123s0-4.052-.505-5.918zM9.546 11.56V4.686l6.273 3.437-6.273 3.437z" />
              </svg>
            </div>
            <div>
              <div style={{ color: "#fff", fontSize: 14, fontWeight: 700 }}>Push — Rodada #12</div>
              <div style={{ color: "#AAAAAA", fontSize: 11, marginTop: 2 }}>Playlist · 10 vídeos</div>
            </div>
          </div>
          <button
            type="button"
            style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: 7, padding: 11, borderRadius: 100, background: "#FF0000", color: "#fff", fontSize: 13, fontWeight: 700, border: "none", cursor: "pointer", fontFamily: "inherit" }}
          >
            <svg width={15} height={12} viewBox="0 0 24 18" fill="white">
              <path d="M23.495 2.205a3.02 3.02 0 0 0-2.122-2.138C19.505 0 12 0 12 0S4.495 0 2.627.07a3.02 3.02 0 0 0-2.122 2.138C0 4.07 0 8.123 0 8.123s0 4.052.505 5.917a3.02 3.02 0 0 0 2.122 2.138C4.495 16.246 12 16.246 12 16.246s7.505 0 9.373-.07a3.02 3.02 0 0 0 2.122-2.138C24 12.175 24 8.123 24 8.123s0-4.052-.505-5.918zM9.546 11.56V4.686l6.273 3.437-6.273 3.437z" />
            </svg>
            Abrir no YouTube
          </button>
        </div>
      )}

      {/* Track list */}
      <div>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: ".07em", textTransform: "uppercase", color: "var(--text-muted)", marginBottom: 12 }}>
          Playlist da semana
        </div>
        {SONGS.map((sg, i) => (
          <div key={sg.id} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 0", borderBottom: i < SONGS.length - 1 ? "1px solid var(--divider)" : "none" }}>
            <div style={{ width: 20, textAlign: "right", fontSize: 12, fontWeight: 700, color: "var(--text-disabled)", flexShrink: 0, fontVariantNumeric: "tabular-nums" }}>
              {i + 1}
            </div>
            <SongCover song={sg} size={38} radius={6} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{sg.title}</div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 1, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{sg.artist}</div>
            </div>
            <div style={{ padding: "2px 6px", borderRadius: 100, background: "rgba(29,185,84,.1)", color: "#1DB954", fontSize: 9, fontWeight: 700, flexShrink: 0 }}>
              {sg.rel.split(" ")[1]}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Screen 4 — Drag-to-rank ─────────────────────────────────────────────────

function RankingScreen({ rankingDone, onDone }: { rankingDone: boolean; onDone: () => void }) {
  const rankedSongs = SONGS.filter((s) => s.sid !== "me");
  const N = rankedSongs.length;
  const ITEM_H = 76;

  const [order, setOrder] = useState(rankedSongs.map((s) => s.id));
  const [dragId, setDragId] = useState<number | null>(null);
  const [dragStartY, setDragStartY] = useState(0);
  const [dragCurrentY, setDragCurrentY] = useState(0);
  const [dragStartIdx, setDragStartIdx] = useState(0);

  const pts = (pos: number) => Math.round(10 - (pos * 9) / (N - 1));

  const dragCurrentIdx =
    dragId !== null
      ? Math.max(0, Math.min(N - 1, dragStartIdx + Math.round((dragCurrentY - dragStartY) / ITEM_H)))
      : -1;

  const visOrder = (() => {
    if (dragId === null) return order;
    const without = order.filter((id) => id !== dragId);
    const result = [...without];
    result.splice(dragCurrentIdx, 0, dragId);
    return result;
  })();

  const commit = useCallback(() => {
    if (dragId === null) return;
    const without = order.filter((id) => id !== dragId);
    const ni = Math.max(0, Math.min(N - 1, dragStartIdx + Math.round((dragCurrentY - dragStartY) / ITEM_H)));
    without.splice(ni, 0, dragId);
    setOrder(without);
    setDragId(null);
  }, [dragId, order, dragStartY, dragCurrentY, dragStartIdx, N, ITEM_H]);

  useEffect(() => {
    const mm = (e: MouseEvent)  => { if (dragId !== null) setDragCurrentY(e.clientY); };
    const mu = ()               => { if (dragId !== null) commit(); };
    const tm = (e: TouchEvent)  => { if (dragId !== null) { e.preventDefault(); setDragCurrentY(e.touches[0].clientY); } };
    const tu = ()               => { if (dragId !== null) commit(); };
    window.addEventListener("mousemove", mm);
    window.addEventListener("mouseup",   mu);
    window.addEventListener("touchmove", tm, { passive: false });
    window.addEventListener("touchend",  tu);
    return () => {
      window.removeEventListener("mousemove", mm);
      window.removeEventListener("mouseup",   mu);
      window.removeEventListener("touchmove", tm);
      window.removeEventListener("touchend",  tu);
    };
  }, [dragId, commit]);

  return (
    <div>
      <div style={{ fontSize: 11, color: "var(--text-muted)", marginBottom: 12, lineHeight: 1.5 }}>
        Arraste para ordenar · #1 = 10 pts · #{N} = 1 pt · sua música não aparece nesta lista
      </div>

      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {visOrder.map((id, pos) => {
          const sg     = rankedSongs.find((s) => s.id === id)!;
          const isDrag = id === dragId;
          return (
            <div
              key={id}
              onMouseDown={(e) => { e.preventDefault(); setDragId(id); setDragStartY(e.clientY); setDragCurrentY(e.clientY); setDragStartIdx(order.indexOf(id)); }}
              onTouchStart={(e) => { setDragId(id); setDragStartY(e.touches[0].clientY); setDragCurrentY(e.touches[0].clientY); setDragStartIdx(order.indexOf(id)); }}
              style={{
                display: "flex", alignItems: "center", gap: 10, padding: "9px 12px",
                borderRadius: 13,
                background: isDrag ? "var(--fill-subtle)" : "var(--surface)",
                border: `1.5px solid ${isDrag ? "var(--accent)" : "var(--divider)"}`,
                cursor: "grab", userSelect: "none",
                boxShadow: isDrag ? "0 8px 28px rgba(0,0,0,.18)" : "0 1px 2px rgba(0,0,0,.04)",
                transform: isDrag ? "scale(1.015)" : "scale(1)",
                transition: isDrag ? "none" : "transform .12s, box-shadow .12s",
                position: "relative", zIndex: isDrag ? 10 : 1,
              }}
            >
              <RankBadge n={pos + 1} active={isDrag} />
              <SongCover song={sg} size={38} radius={6} />
              <div style={{ flex: 1, minWidth: 0 }}>
                <div style={{ fontSize: 12, fontWeight: 700, color: isDrag ? "var(--accent)" : "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {sg.title}
                </div>
                <div style={{ fontSize: 10, color: "var(--text-muted)", marginTop: 2, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                  {sg.artist}
                </div>
              </div>
              <div style={{ textAlign: "center", flexShrink: 0, minWidth: 34 }}>
                <div style={{ fontSize: 17, fontWeight: 900, color: isDrag ? "var(--accent)" : "var(--text)", lineHeight: 1 }}>{pts(pos)}</div>
                <div style={{ fontSize: 8, fontWeight: 600, color: "var(--text-muted)", letterSpacing: ".05em", marginTop: 1 }}>PTS</div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 2.5, paddingLeft: 2, flexShrink: 0 }}>
                {[0, 1, 2].map((row) => (
                  <div key={row} style={{ display: "flex", gap: 2.5 }}>
                    <div style={{ width: 3, height: 3, borderRadius: 1.5, background: "var(--text-disabled)" }} />
                    <div style={{ width: 3, height: 3, borderRadius: 1.5, background: "var(--text-disabled)" }} />
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {rankingDone ? (
        <div style={{ marginTop: 16, display: "flex", alignItems: "center", justifyContent: "center", gap: 8 }}>
          <div style={{ width: 20, height: 20, borderRadius: 10, background: "#1DB954", display: "flex", alignItems: "center", justifyContent: "center" }}>
            <CheckIcon color="white" size={10} />
          </div>
          <span style={{ fontSize: 13, fontWeight: 600, color: "#1DB954" }}>Ranking enviado com sucesso!</span>
        </div>
      ) : (
        <button
          type="button"
          onClick={onDone}
          style={{ marginTop: 16, width: "100%", padding: 14, borderRadius: 14, border: "none", background: "var(--accent)", color: "white", fontSize: 15, fontWeight: 700, cursor: "pointer", fontFamily: "inherit" }}
        >
          Confirmar meu ranking
        </button>
      )}
    </div>
  );
}

// ─── Screen 5 — Results ──────────────────────────────────────────────────────

function ResultsScreen() {
  const [tab, setTab] = useState<ResultTab>("round");
  const byId = (sid: number) => SONGS.find((s) => s.id === sid)!;

  const tabBtnStyle = (active: boolean): CSSProperties => ({
    flex: 1, padding: "7px 4px", borderRadius: 8, border: "none", fontSize: 12, fontWeight: 600,
    cursor: "pointer", fontFamily: "inherit",
    background: active ? "var(--surface)" : "transparent",
    color: active ? "var(--text)" : "var(--text-muted)",
    boxShadow: active ? "0 1px 3px rgba(0,0,0,.08)" : "none",
    transition: "background .15s",
  });

  return (
    <div>
      {/* My result */}
      <div style={{ display: "flex", alignItems: "center", gap: 11, marginBottom: 16, padding: 13, background: "var(--surface)", borderRadius: 14, border: "1px solid var(--divider)" }}>
        <SongCover song={MY_SONG} size={46} />
        <div style={{ flex: 1, minWidth: 0 }}>
          <div style={{ fontSize: 14, fontWeight: 700, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{MY_SONG.title}</div>
          <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 1 }}>{MY_SONG.artist}</div>
        </div>
        <div style={{ textAlign: "right", flexShrink: 0 }}>
          <div style={{ fontSize: 10, color: "var(--text-muted)", letterSpacing: ".05em", textTransform: "uppercase", marginBottom: 3 }}>Posição</div>
          <div style={{ fontSize: 30, fontWeight: 900, color: PODIUM_COLORS[2], lineHeight: 1 }}>#3</div>
          <div style={{ fontSize: 13, fontWeight: 700, color: "var(--text)" }}>+71 pts</div>
        </div>
      </div>

      {/* Tabs */}
      <div style={{ display: "flex", gap: 0, background: "var(--fill-subtle)", borderRadius: 10, padding: 3, marginBottom: 16 }}>
        {(["round", "season", "geral"] as ResultTab[]).map((t) => (
          <button key={t} type="button" onClick={() => setTab(t)} style={tabBtnStyle(tab === t)}>
            {t === "round" ? "Rodada" : t === "season" ? "Temporada" : "Geral"}
          </button>
        ))}
      </div>

      {tab === "round" && (
        <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
          {RESULTS.map((r) => {
            const sg   = byId(r.sid);
            const isMe = sg.sid === "me";
            return (
              <div key={r.rank} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", background: isMe ? "color-mix(in srgb, var(--accent) 8%, transparent)" : "var(--surface)", border: `1px solid ${isMe ? "color-mix(in srgb, var(--accent) 20%, transparent)" : "var(--divider)"}`, borderRadius: 12 }}>
                <RankBadge n={r.rank} />
                <SongCover song={sg} size={36} radius={6} />
                <div style={{ flex: 1, minWidth: 0 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{sg.title}</div>
                  <div style={{ fontSize: 10, color: "var(--text-muted)", marginTop: 1 }}>{sg.sname} · {sg.rel.split(" ")[1]}</div>
                </div>
                <div style={{ textAlign: "right", flexShrink: 0 }}>
                  <div style={{ fontSize: 16, fontWeight: 800, color: isMe ? "var(--accent)" : "var(--text)" }}>{r.pts}</div>
                  <div style={{ fontSize: 9, fontWeight: 600, color: "var(--text-muted)", letterSpacing: ".04em" }}>PTS</div>
                </div>
              </div>
            );
          })}
        </div>
      )}

      {(tab === "season" || tab === "geral") && (
        <div>
          <div style={{ fontSize: 10, fontWeight: 700, color: "var(--text-muted)", letterSpacing: ".07em", textTransform: "uppercase", marginBottom: 12 }}>
            {tab === "season" ? "Temporada 2" : "Ranking Geral"}
          </div>
          <div style={{ display: "flex", flexDirection: "column", gap: 7 }}>
            {OVERALL.map((m) => (
              <div key={m.pos} style={{ display: "flex", alignItems: "center", gap: 10, padding: "9px 12px", background: m.me ? "color-mix(in srgb, var(--accent) 8%, transparent)" : "var(--surface)", border: `1px solid ${m.me ? "color-mix(in srgb, var(--accent) 20%, transparent)" : "var(--divider)"}`, borderRadius: 12 }}>
                <RankBadge n={m.pos} />
                <MiniAvatar name={m.name} size={32} />
                <div style={{ flex: 1 }}>
                  <div style={{ fontSize: 13, fontWeight: 700, color: m.me ? "var(--accent)" : "var(--text)" }}>{m.name}</div>
                  <div style={{ fontSize: 10, color: "var(--text-muted)", marginTop: 1 }}>{m.rounds} rodadas</div>
                </div>
                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: 16, fontWeight: 800, color: m.me ? "var(--accent)" : "var(--text)" }}>{m.pts}</div>
                  <div style={{ fontSize: 9, fontWeight: 600, color: "var(--text-muted)", letterSpacing: ".04em" }}>PTS</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

// ─── Desktop sidebar ─────────────────────────────────────────────────────────

function StatsSidebar({ stage }: { stage: Stage }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
      {/* Participants */}
      <div style={{ background: "var(--surface)", borderRadius: 18, border: "1px solid var(--divider)", padding: "18px 20px", boxShadow: "0 1px 2px rgba(0,0,0,.04)" }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: ".07em", textTransform: "uppercase", color: "var(--text-muted)", marginBottom: 14 }}>
          Participantes
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 9 }}>
          {MEMBERS.map((m) => (
            <div key={m.id} style={{ display: "flex", alignItems: "center", gap: 10 }}>
              <MiniAvatar name={m.name} size={30} />
              <div style={{ flex: 1, fontSize: 13, fontWeight: 600, color: "var(--text)" }}>
                {m.id === "me" ? "Você" : m.name.split(" ")[0]}
              </div>
              <div style={{ width: 18, height: 18, borderRadius: 9, background: m.done ? "#1DB954" : "var(--fill-subtle)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
                {m.done && <CheckIcon color="white" size={8} />}
              </div>
            </div>
          ))}
        </div>
        <div style={{ marginTop: 14, paddingTop: 12, borderTop: "1px solid var(--divider)", fontSize: 12, color: "var(--text-muted)", textAlign: "center" }}>
          {MEMBERS.filter((m) => m.done).length}/{MEMBERS.length} indicaram
        </div>
      </div>

      {/* Round info */}
      <div style={{ background: "var(--surface)", borderRadius: 18, border: "1px solid var(--divider)", padding: "18px 20px", boxShadow: "0 1px 2px rgba(0,0,0,.04)" }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: ".07em", textTransform: "uppercase", color: "var(--text-muted)", marginBottom: 12 }}>
          Rodada #12
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {[
            { label: "Temporada",    value: "2",             accent: false },
            { label: "Músicas",      value: "10",            accent: false },
            { label: "Fase atual",   value: STAGE_LABEL[stage], accent: true  },
            { label: "Tempo restante", value: STAGE_TIME[stage], accent: false },
          ].map(({ label, value, accent }) => (
            <div key={label} style={{ display: "flex", justifyContent: "space-between", fontSize: 13 }}>
              <span style={{ color: "var(--text-muted)" }}>{label}</span>
              <span style={{ fontWeight: 600, color: accent ? "var(--accent)" : "var(--text)" }}>{value}</span>
            </div>
          ))}
        </div>
      </div>

      {/* Rules summary */}
      <div style={{ background: "var(--surface)", borderRadius: 18, border: "1px solid var(--divider)", padding: "18px 20px", boxShadow: "0 1px 2px rgba(0,0,0,.04)" }}>
        <div style={{ fontSize: 11, fontWeight: 700, letterSpacing: ".07em", textTransform: "uppercase", color: "var(--text-muted)", marginBottom: 12 }}>
          Regras
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {[
            "Lançamento máx. 12 meses",
            "1 indicação por membro",
            "Músicas ficam ocultas até revelar",
            "#1 = 10 pts · último = 1 pt",
          ].map((rule, i) => (
            <div key={i} style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
              <div style={{ width: 16, height: 16, borderRadius: 8, background: "color-mix(in srgb, var(--accent) 12%, transparent)", color: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, fontWeight: 800, flexShrink: 0, marginTop: 1 }}>
                {i + 1}
              </div>
              <div style={{ fontSize: 12, color: "var(--text-subtle)", lineHeight: 1.5 }}>{rule}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

// ─── Main export ─────────────────────────────────────────────────────────────

export function PushClient() {
  const isMobile = useIsMobile();
  const [stage, setStage] = useState<Stage>("submission");
  const [submitted, setSubmitted] = useState(false);
  const [rankingDone, setRankingDone] = useState(false);

  const renderScreen = () => {
    switch (stage) {
      case "submission":
        return <SubmissionScreen submitted={submitted} onSubmit={() => setSubmitted(true)} onClear={() => setSubmitted(false)} />;
      case "waiting":
        return <WaitingScreen />;
      case "listening":
        return <ListeningScreen />;
      case "ranking":
        return <RankingScreen rankingDone={rankingDone} onDone={() => setRankingDone(true)} />;
      case "results":
        return <ResultsScreen />;
    }
  };

  return (
    <div style={{ padding: isMobile ? "0 16px 88px" : "0 40px 60px" }}>

      {/* Stage demo switcher */}
      <div style={{ display: "flex", gap: 6, overflowX: "auto", padding: "16px 0 12px", WebkitOverflowScrolling: "touch" as React.CSSProperties["WebkitOverflowScrolling"] }}>
        {(Object.keys(STAGE_LABEL) as Stage[]).map((s) => (
          <button
            key={s}
            type="button"
            onClick={() => setStage(s)}
            style={{ padding: "4px 12px", borderRadius: 100, border: "none", fontSize: 11, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", background: stage === s ? "var(--accent)" : "var(--fill-subtle)", color: stage === s ? "white" : "var(--text-muted)", flexShrink: 0, transition: "background 120ms" }}
          >
            {STAGE_LABEL[s]}
          </button>
        ))}
      </div>

      {/* Round header card */}
      <div style={{ background: "var(--surface)", borderRadius: 16, border: "1px solid var(--divider)", padding: isMobile ? "14px 16px" : "18px 22px", marginBottom: 24 }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 12 }}>
          <div>
            <div style={{ fontSize: 10, fontWeight: 700, color: "var(--text-muted)", letterSpacing: ".07em", textTransform: "uppercase", marginBottom: 4 }}>
              Rodada #12 · Temporada 2
            </div>
            <div style={{ fontSize: isMobile ? 22 : 26, fontWeight: 900, color: "var(--text)", letterSpacing: "-.03em", lineHeight: 1 }}>PUSH</div>
          </div>
          <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 5 }}>
            <div style={{ padding: "3px 10px", borderRadius: 100, background: "color-mix(in srgb, var(--accent) 10%, transparent)", color: "var(--accent)", fontSize: 10, fontWeight: 800, letterSpacing: ".04em" }}>
              {STAGE_LABEL[stage].toUpperCase()}
            </div>
            <div style={{ fontSize: 10, color: "var(--text-muted)", fontVariantNumeric: "tabular-nums" }}>
              {STAGE_TIME[stage]}
            </div>
          </div>
        </div>
        <StageBar activeIndex={STAGE_INDEX[stage]} />
      </div>

      {/* Responsive content */}
      {isMobile ? (
        renderScreen()
      ) : (
        <div style={{ display: "grid", gridTemplateColumns: "1fr 280px", gap: 28, alignItems: "flex-start" }}>
          <div>{renderScreen()}</div>
          <div style={{ position: "sticky", top: 88 }}>
            <StatsSidebar stage={stage} />
          </div>
        </div>
      )}
    </div>
  );
}
