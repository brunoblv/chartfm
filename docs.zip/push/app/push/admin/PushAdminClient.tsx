"use client";

import { useState } from "react";
import { useIsMobile } from "@/hooks/useIsMobile";
import type { CSSProperties } from "react";

// ─── Types ───────────────────────────────────────────────────────────────────

type AdminTab = "rounds" | "members" | "rules" | "history";
type StageStatus = "done" | "active" | "pending";

interface AdminStage {
  name: string;
  start: string;
  end: string;
  status: StageStatus;
}

interface AdminDuration {
  sub: number;
  listen: number;
  vote: number;
}

interface Rule {
  text: string;
}

// ─── Data ───────────────────────────────────────────────────────────────────

const STAGES: AdminStage[] = [
  { name: "Inscrição", start: "12 Jun 10:00", end: "14 Jun 10:00", status: "done"    },
  { name: "Revelação", start: "14 Jun 10:00", end: "14 Jun 11:00", status: "done"    },
  { name: "Escuta",    start: "14 Jun 11:00", end: "17 Jun 11:00", status: "done"    },
  { name: "Avaliação", start: "17 Jun 11:00", end: "18 Jun 11:00", status: "active"  },
  { name: "Resultado", start: "—",            end: "—",            status: "pending" },
];

const RULES: Rule[] = [
  { text: "Lançamento máximo de 12 meses (data do álbum no Spotify)" },
  { text: "Cada música só pode ser indicada uma única vez em qualquer rodada" },
  { text: "Cada membro indica exatamente 1 música por rodada" },
  { text: "Músicas ficam ocultas até o encerramento das inscrições" },
  { text: "O membro não pode ranquear a própria música indicada" },
  { text: "Pontuação: #1 = 10 pts → último = 1 pt (distribuição linear)" },
];

const MEMBERS_LIST = [
  { name: "Mariana R.", handle: "mariana",  rounds: 12, pts: 487, status: "Ativo"    },
  { name: "Pedro S.",   handle: "pedro",    rounds: 11, pts: 398, status: "Ativo"    },
  { name: "Ana C.",     handle: "ana",      rounds: 12, pts: 432, status: "Ativo"    },
  { name: "Carlos M.",  handle: "carlos",   rounds: 11, pts: 318, status: "Ativo"    },
  { name: "Felipe R.",  handle: "felipe",   rounds: 10, pts: 352, status: "Ausente"  },
  { name: "Roberta L.", handle: "roberta",  rounds: 10, pts: 295, status: "Ausente"  },
  { name: "Lucas B.",   handle: "lucas",    rounds: 9,  pts: 271, status: "Inativo"  },
  { name: "Camila F.",  handle: "camila",   rounds: 12, pts: 301, status: "Ativo"    },
  { name: "Rafael D.",  handle: "rafael",   rounds: 11, pts: 284, status: "Ativo"    },
  { name: "Bruno S.",   handle: "bruno",    rounds: 12, pts: 371, status: "Ativo"    },
];

const HISTORY = [
  { round: 11, winner: "APT.", artist: "ROSÉ & Bruno Mars", date: "Jun 10", pts: 91 },
  { round: 10, winner: "Espresso", artist: "Sabrina Carpenter", date: "Jun 3", pts: 88 },
  { round: 9,  winner: "TEXAS HOLD EM", artist: "Beyoncé", date: "Mai 27", pts: 85 },
  { round: 8,  winner: "Not Like Us", artist: "Kendrick Lamar", date: "Mai 20", pts: 79 },
  { round: 7,  winner: "Die With A Smile", artist: "Lady Gaga & Bruno Mars", date: "Mai 13", pts: 82 },
];

// ─── Shared atoms ─────────────────────────────────────────────────────────────

function MiniAvatar({ name, size = 32 }: { name: string; size?: number }) {
  const hue = Math.abs(name.split("").reduce((a, c) => (a * 31 + c.charCodeAt(0)) | 0, 0)) % 360;
  return (
    <div style={{ width: size, height: size, borderRadius: size / 2, flexShrink: 0, background: `hsl(${hue},42%,52%)`, display: "flex", alignItems: "center", justifyContent: "center", color: "white", fontSize: Math.floor(size * 0.4), fontWeight: 700 }}>
      {name[0].toUpperCase()}
    </div>
  );
}

function CheckIcon() {
  return (
    <svg width={10} height={10} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={3} strokeLinecap="round" strokeLinejoin="round">
      <path d="M20 6L9 17l-5-5" />
    </svg>
  );
}

// ─── Subviews ─────────────────────────────────────────────────────────────────

function RoundsTab({ dur, setDur }: { dur: AdminDuration; setDur: (d: AdminDuration) => void }) {
  return (
    <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(300px, 1fr))", gap: 24 }}>

      {/* Stage timeline */}
      <div>
        <div style={{ fontSize: 11, fontWeight: 700, color: "var(--text-muted)", letterSpacing: ".07em", textTransform: "uppercase", marginBottom: 14 }}>
          Etapas — Rodada #12
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {STAGES.map((s) => (
            <div key={s.name} style={{ display: "flex", alignItems: "center", gap: 12, padding: "12px 14px", borderRadius: 12, background: s.status === "active" ? "color-mix(in srgb, var(--accent) 6%, transparent)" : "var(--fill-inset)", border: `1.5px solid ${s.status === "active" ? "color-mix(in srgb, var(--accent) 28%, transparent)" : "var(--divider)"}` }}>
              <div style={{ width: 9, height: 9, borderRadius: 5, flexShrink: 0, background: s.status === "done" ? "#1DB954" : s.status === "active" ? "var(--accent)" : "var(--text-disabled)" }} />
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, fontWeight: 700, color: s.status === "pending" ? "var(--text-muted)" : "var(--text)" }}>{s.name}</div>
                <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>
                  {s.status !== "pending" ? `${s.start} → ${s.end}` : "Aguardando etapa anterior"}
                </div>
              </div>
              {s.status === "done"    && <span style={{ fontSize: 11, fontWeight: 600, color: "#1DB954", display: "flex", alignItems: "center", gap: 4 }}><CheckIcon /> Concluída</span>}
              {s.status === "active"  && <span style={{ padding: "3px 9px", borderRadius: 100, background: "color-mix(in srgb, var(--accent) 12%, transparent)", color: "var(--accent)", fontSize: 11, fontWeight: 700, whiteSpace: "nowrap" }}>Em andamento</span>}
              {s.status === "pending" && <span style={{ fontSize: 11, color: "var(--text-disabled)", whiteSpace: "nowrap" }}>Pendente</span>}
            </div>
          ))}
        </div>
      </div>

      {/* Duration sliders */}
      <div>
        <div style={{ fontSize: 11, fontWeight: 700, color: "var(--text-muted)", letterSpacing: ".07em", textTransform: "uppercase", marginBottom: 14 }}>
          Duração das Etapas (próxima rodada)
        </div>
        <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {([["sub", "Inscrição", dur.sub], ["listen", "Escuta", dur.listen], ["vote", "Avaliação", dur.vote]] as [keyof AdminDuration, string, number][]).map(([key, label, val]) => (
            <div key={key} style={{ background: "var(--fill-inset)", borderRadius: 12, padding: "13px 15px", border: "1px solid var(--divider)" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 10 }}>
                <span style={{ fontSize: 11, fontWeight: 700, color: "var(--text-muted)", letterSpacing: ".04em", textTransform: "uppercase" }}>{label}</span>
                <span style={{ fontSize: 20, fontWeight: 900, color: "var(--text)", letterSpacing: "-.03em" }}>{val}h</span>
              </div>
              <input
                type="range"
                min={1}
                max={168}
                value={val}
                onChange={(e) => setDur({ ...dur, [key]: Number(e.target.value) })}
                style={{ width: "100%", accentColor: "var(--accent)", cursor: "pointer" }}
              />
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

function MembersTab() {
  const statusColor: Record<string, string> = {
    Ativo:   "var(--up-fg)",
    Ausente: "var(--accent)",
    Inativo: "var(--text-disabled)",
  };
  const statusBg: Record<string, string> = {
    Ativo:   "var(--up-bg)",
    Ausente: "var(--down-bg)",
    Inativo: "var(--fill-subtle)",
  };

  return (
    <div>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(280px, 1fr))", gap: 10 }}>
        {MEMBERS_LIST.map((m) => (
          <div key={m.handle} style={{ background: "var(--surface)", borderRadius: 12, border: "1px solid var(--divider)", padding: "13px 16px", display: "flex", alignItems: "center", gap: 12 }}>
            <MiniAvatar name={m.name} size={38} />
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{m.name}</div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>@{m.handle} · {m.rounds} rodadas</div>
            </div>
            <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 5 }}>
              <span style={{ padding: "2px 8px", borderRadius: 100, background: statusBg[m.status], color: statusColor[m.status], fontSize: 10, fontWeight: 700 }}>
                {m.status}
              </span>
              <span style={{ fontSize: 13, fontWeight: 700, color: "var(--text)", fontVariantNumeric: "tabular-nums" }}>
                {m.pts} pts
              </span>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

function RulesTab() {
  const [editing, setEditing] = useState<number | null>(null);
  return (
    <div style={{ maxWidth: 700 }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {RULES.map((rule, i) => (
          <div key={i} style={{ display: "flex", gap: 12, alignItems: "flex-start", padding: "12px 16px", background: "var(--surface)", borderRadius: 12, border: `1px solid ${editing === i ? "var(--accent)" : "var(--divider)"}`, transition: "border-color 150ms" }}>
            <div style={{ width: 22, height: 22, borderRadius: 11, background: "color-mix(in srgb, var(--accent) 12%, transparent)", color: "var(--accent)", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 10, fontWeight: 800, flexShrink: 0, marginTop: 1 }}>
              {i + 1}
            </div>
            {editing === i ? (
              <textarea
                defaultValue={rule.text}
                autoFocus
                onBlur={() => setEditing(null)}
                style={{ flex: 1, fontSize: 13, color: "var(--text)", lineHeight: 1.6, background: "transparent", border: "none", outline: "none", resize: "none", fontFamily: "inherit", minHeight: 48 }}
              />
            ) : (
              <div style={{ flex: 1, fontSize: 13, color: "var(--text)", lineHeight: 1.6 }}>{rule.text}</div>
            )}
            <button
              type="button"
              onClick={() => setEditing(editing === i ? null : i)}
              style={{ background: "none", border: "none", cursor: "pointer", color: "var(--text-muted)", padding: 4, flexShrink: 0, marginTop: 1 }}
            >
              <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
                <path d="M11 4H4a2 2 0 0 0-2 2v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2v-7" />
                <path d="M18.5 2.5a2.121 2.121 0 0 1 3 3L12 15l-4 1 1-4 9.5-9.5z" />
              </svg>
            </button>
          </div>
        ))}
      </div>
      <button
        type="button"
        style={{ marginTop: 12, padding: "9px 18px", borderRadius: 100, border: "1px dashed var(--divider)", background: "transparent", color: "var(--text-muted)", fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", display: "flex", alignItems: "center", gap: 7 }}
      >
        <svg width={14} height={14} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2.5} strokeLinecap="round"><line x1={12} y1={5} x2={12} y2={19}/><line x1={5} y1={12} x2={19} y2={12}/></svg>
        Adicionar regra
      </button>
    </div>
  );
}

function HistoryTab() {
  const podiumColors = ["#FFD700", "#C0C0C0", "#CD7F32"];
  return (
    <div style={{ maxWidth: 640 }}>
      <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
        {HISTORY.map((h) => (
          <div key={h.round} style={{ display: "flex", alignItems: "center", gap: 14, padding: "13px 16px", background: "var(--surface)", borderRadius: 13, border: "1px solid var(--divider)" }}>
            <div style={{ width: 36, height: 36, borderRadius: 9, background: "color-mix(in srgb, var(--accent) 8%, transparent)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
              <span style={{ fontSize: 13, fontWeight: 800, color: "var(--accent)" }}>#{h.round}</span>
            </div>
            <div style={{ flex: 1, minWidth: 0 }}>
              <div style={{ fontSize: 14, fontWeight: 700, color: "var(--text)", overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>{h.winner}</div>
              <div style={{ fontSize: 11, color: "var(--text-muted)", marginTop: 2 }}>{h.artist} · {h.date}</div>
            </div>
            <div style={{ textAlign: "right", flexShrink: 0 }}>
              <div style={{ fontSize: 15, fontWeight: 800, color: podiumColors[0] }}>{h.pts} pts</div>
              <div style={{ fontSize: 9, fontWeight: 600, color: "var(--text-muted)", letterSpacing: ".04em" }}>1º LUGAR</div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Main ────────────────────────────────────────────────────────────────────

export function PushAdminClient() {
  const isMobile = useIsMobile();
  const [activeTab, setActiveTab] = useState<AdminTab>("rounds");
  const [dur, setDur] = useState<AdminDuration>({ sub: 48, listen: 72, vote: 24 });

  const tabBtnStyle = (active: boolean): CSSProperties => ({
    display: "flex",
    alignItems: "center",
    gap: 8,
    padding: "9px 12px",
    borderRadius: 9,
    border: "none",
    background: active ? "var(--accent-tint)" : "transparent",
    color: active ? "var(--accent)" : "var(--text-muted)",
    fontWeight: active ? 700 : 500,
    fontSize: 14,
    cursor: "pointer",
    fontFamily: "inherit",
    letterSpacing: "-0.01em",
    whiteSpace: "nowrap" as const,
    transition: "background 120ms",
    textAlign: "left" as const,
    width: isMobile ? "auto" : "100%",
  });

  const TABS: { id: AdminTab; label: string }[] = [
    { id: "rounds",  label: "Rodadas"   },
    { id: "members", label: "Membros"   },
    { id: "rules",   label: "Regras"    },
    { id: "history", label: "Histórico" },
  ];

  const renderTab = () => {
    switch (activeTab) {
      case "rounds":  return <RoundsTab dur={dur} setDur={setDur} />;
      case "members": return <MembersTab />;
      case "rules":   return <RulesTab />;
      case "history": return <HistoryTab />;
    }
  };

  return (
    <div style={{ padding: isMobile ? "0 16px 88px" : "0 40px 60px" }}>

      {/* Page header */}
      <div style={{ paddingTop: 24, paddingBottom: 20, display: "flex", alignItems: "flex-end", justifyContent: "space-between", gap: 16 }}>
        <div>
          <div style={{ fontSize: 11, fontWeight: 700, color: "var(--text-muted)", letterSpacing: ".07em", textTransform: "uppercase", marginBottom: 4 }}>
            Temporada 2 · Rodada #12
          </div>
          <h1 style={{ fontSize: isMobile ? 26 : 34, fontWeight: 900, letterSpacing: "-.04em", margin: 0, lineHeight: 1.05, color: "var(--text)" }}>
            Push Admin
          </h1>
        </div>
        <div style={{ display: "flex", gap: 8, flexShrink: 0 }}>
          <button
            type="button"
            style={{ padding: "9px 16px", borderRadius: 100, background: "var(--fill-subtle)", color: "var(--text)", border: "1px solid var(--divider-strong)", fontSize: 13, fontWeight: 600, cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap" }}
          >
            Encerrar etapa
          </button>
          <button
            type="button"
            style={{ padding: "9px 16px", borderRadius: 100, background: "var(--accent)", color: "white", border: "none", fontSize: 13, fontWeight: 700, cursor: "pointer", fontFamily: "inherit", whiteSpace: "nowrap" }}
          >
            Nova Rodada
          </button>
        </div>
      </div>

      {isMobile ? (
        /* Mobile: horizontal scrollable tab bar */
        <div>
          <div style={{ display: "flex", gap: 4, overflowX: "auto", WebkitOverflowScrolling: "touch" as React.CSSProperties["WebkitOverflowScrolling"], marginBottom: 20, paddingBottom: 2 }}>
            {TABS.map((t) => (
              <button key={t.id} type="button" onClick={() => setActiveTab(t.id)} style={{ ...tabBtnStyle(activeTab === t.id), flexShrink: 0 }}>
                {t.label}
              </button>
            ))}
          </div>
          {renderTab()}
        </div>
      ) : (
        /* Desktop: sidebar nav + content */
        <div style={{ display: "grid", gridTemplateColumns: "200px 1fr", gap: 32, alignItems: "flex-start" }}>
          <nav style={{ position: "sticky", top: 88, display: "flex", flexDirection: "column", gap: 2 }}>
            {TABS.map((t) => (
              <button key={t.id} type="button" onClick={() => setActiveTab(t.id)} style={tabBtnStyle(activeTab === t.id)}>
                {t.label}
              </button>
            ))}
          </nav>
          <div>{renderTab()}</div>
        </div>
      )}
    </div>
  );
}
