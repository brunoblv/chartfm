import type { Metadata } from "next";
import { Shell } from "@/components/layout/Shell";
import { PushAdminClient } from "./PushAdminClient";

export const metadata: Metadata = {
  title: "Push Admin · ChartFM",
  description: "Painel administrativo do Push — gerencie rodadas, etapas e regras.",
};

export default function PushAdminPage() {
  return (
    <Shell title="" noPadding>
      <PushAdminClient />
    </Shell>
  );
}
