import type { Metadata } from "next";
import { Shell } from "@/components/layout/Shell";
import { PushClient } from "./PushClient";

export const metadata: Metadata = {
  title: "Push · ChartFM",
  description: "Indique músicas, ouça e ranqueie com seus amigos no Push.",
};

export default function PushPage() {
  return (
    <Shell title="" noPadding>
      <PushClient />
    </Shell>
  );
}
