# Plano de Ação: Resolução de Rejeição por "Conteúdo Pobre" (Thin Content) no Google AdSense

Este documento apresenta o diagnóstico e o plano de ação passo a passo para adequar o **ChartFM** às diretrizes do Google AdSense, revertendo a rejeição por "conteúdo de baixo valor" ou "conteúdo pobre".

---

## 🔍 Diagnóstico do Cenário Atual

O ChartFM possui uma base técnica e de dados sólida, mas esbarra no principal critério do Google AdSense para aprovação: **conteúdo editorial textual original**.

### 🟢 O que está correto (Estrutura Técnica)
* **Páginas Institucionais Vitais:** Presença de mecanismos de consentimento (`lib/consent.tsux`) e do arquivo de identificação obrigatório (`public/ads.txt`).
* **Estrutura de Blocos:** O gerenciamento de anúncios já está mapeado via `lib/adsense-slots.tsux`.
* **Arquitetura de Dados:** Sistema robusto de rotas musicais (`lib/music-routes.tsux`), snapshots de entidades (`lib/entity-page-snapshot/`) e classificação de álbuns (`lib/album-score.tsux`).

### 🔴 O que causou a rejeição (O Gargalo)
Para os robôs de validação do AdSense, agregadores de dados, painéis de estatísticas, listas de reprodução ou ferramentas automáticas baseadas em APIs (como Last.fm e Spotify) são classificados como **"Thin Content"**. O algoritmo precisa de **parágrafos de texto legível (artigos, resenhas, guias)** para entender o contexto do site e contextualizar os anúncios.

---

## 🛠️ Passo a Passo para Resolver e Obter a Aprovação

Siga estas 4 etapas antes de solicitar uma nova revisão no painel do Google AdSense.

### Etapa 1: Implementar as Páginas Jurídicas e Institucionais Obrigatórias
O AdSense exige por contrato que o usuário consiga acessar as políticas do site a partir de qualquer página.
1. Crie rotas estáticas em seu Next.js para:
   * `/politica-de-privacidade` (Detallhando o uso de cookies, a coleta de dados de navegação e a veiculação de anúncios por terceiros/Google).
   * `/termos-de-uso` (Regras de utilização da plataforma ChartFM).
   * `/sobre` (Texto institucional humanizado explicando o propósito do projeto, quem o administra e os objetivos da comunidade).
2. Adicione links diretos e visíveis para essas páginas no rodapé global do site (ex: no componente de layout `lib/page-layout.tsux`).

### Etapa 2: Validar e Fixar o `ads.txt`
1. Certifique-se de que o arquivo `public/ads.txt` esteja respondendo perfeitamente na raiz do seu domínio cadastrado: `https://seu-dominio.com/ads.txt`.
2. O conteúdo deve seguir exatamente o padrão fornecido pelo Google:
   ```text
   google.com, pub-XXXXXXXXXXXXXXXX, DIRECT, f08c47fec0942fa0
   ```
   *(Substitua o `pub-XXXXXXXXXXXXXXXX` pelo seu ID de editor real do AdSense).*

### Etapa 3: Criar uma Camada Editorial Textual (Mínimo de 10 a 15 Artigos)
Aproveite as estruturas existentes que você já começou a planejar (como `lib/editorial-generator.tsux` e `lib/editorial-picks.tsux`) para injetar texto denso no site.
1. **Seção de Notícias ou Blog:** Escreva de 10 a 15 artigos originais sobre o universo da música (análises de lançamentos da semana, história de um álbum clássico, novidades sobre turnês).
2. **Extensão Mínima:** Cada artigo deve conter entre **400 e 600 palavras** de texto fluido, dividido em parágrafos normais (evite tópicos curtos e tabelas nesta seção).
3. **Críticas e Resenhas de Álbuns (Reviews):** Em vez de apenas exibir as notas numéricas geradas por `lib/album-score.tsux`, crie um campo ou uma seção dedicada a críticas de álbuns escritas de forma dissertativa.

### Etapa 4: Blindagem contra Páginas Vazias e Erros de Indexação
Quando o revisor do Google (ou o robô) analisa o site, ele varre links aleatórios gerados pelo seu sistema.
1. **Evite Soft 404:** Se uma página de artista ou álbum nos arquivos de snapshot (`lib/entity-page-snapshot/`) não possuir dados suficientes ou estiver sem bio, retorne um status HTTP 404 real ou oculte temporariamente o link de listagens públicas para que o robô não a indexe vazia.
2. **Injeção de Contexto:** Enriqueça a página dos artistas trazendo biografias textuais (via integração de texto ou resumos locais) logo acima das tabelas de estatísticas e scrobbles.

---

## 🎯 Resumo da Estratégia de Reenvio

Após aplicar as mudanças acima:
1. Deixe os novos artigos textuais em destaque na página inicial por alguns dias.
2. Certifique-se de que o Google Search Console indexou as novas páginas de texto e as páginas de política de privacidade.
3. Acesse o painel do **Google AdSense > Sites**, clique no seu domínio e selecione **"Solicitar revisão"**.

Com a mistura entre a sua robusta ferramenta estatística musical e uma camada de blog/notícias textual legítima, o AdSense interpretará o site como um portal de conteúdo rico de alto valor.
