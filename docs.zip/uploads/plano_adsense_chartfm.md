# Plano de melhoria do ChartFM para nova análise do AdSense

## Objetivo

Este documento reúne o diagnóstico inicial do ChartFM e um plano prático
para melhorar a qualidade percebida do site antes de uma nova
solicitação de análise do AdSense.

A conclusão principal é que o ChartFM **não parece ser um projeto sem
conteúdo ou sem valor**. O site possui funcionalidades próprias, dados
originais, rankings, jogos, comunidades, avaliações, guias e conteúdo
editorial.

O principal risco é outro: para um avaliador externo ou sistema
automatizado, uma parte importante do site pode parecer composta
principalmente por:

-   listas;
-   rankings;
-   cards;
-   capas;
-   números;
-   páginas programáticas;
-   páginas utilitárias;
-   páginas muito semelhantes entre si;
-   conteúdo dependente de login;
-   páginas com pouca interpretação editorial.

A estratégia recomendada não é transformar o ChartFM em um blog
genérico.

A estratégia é:

> **Dados → contexto → análise → descoberta → navegação interna**

------------------------------------------------------------------------

# 1. Diagnóstico geral

## Situação atual por área

  -----------------------------------------------------------------------
  Área                    Situação                Prioridade
  ----------------------- ----------------------- -----------------------
  Funcionalidade própria  Muito boa               Manter

  Conteúdo original       Grande potencial        Expandir
  baseado em dados                                

  Guias                   Bons                    Melhorar links internos

  Páginas institucionais  Presentes               Revisar e fortalecer

  Editorial               Existe, mas ainda       Alta
                          pequeno                 

  Páginas de artistas     Boas, porém muito       Alta
                          orientadas a dados      

  Páginas de músicas      Precisam de mais        Alta
                          contexto                

  Páginas de álbuns       Precisam de maior       Alta
                          profundidade            

  Sitemap                 Incompleto              Crítica

  Controle de indexação   Precisa de revisão      Crítica

  Conteúdo baseado em     Precisa de revisão      Crítica
  fatos verificáveis                              

  Navegação para          Precisa de auditoria    Alta
  visitante anônimo                               

  Arquitetura geral para  Próxima do ideal, mas   Alta
  AdSense                 ainda precisa de        
                          ajustes                 
  -----------------------------------------------------------------------

------------------------------------------------------------------------

# 2. Problema central

O ChartFM possui muitas funcionalidades, mas funcionalidade não é
automaticamente interpretada como conteúdo de alto valor.

Por exemplo, estas funcionalidades são excelentes como produto:

-   Global 100;
-   Airplay Chart;
-   Albums Chart;
-   charts pessoais;
-   Push;
-   Copa ChartFM;
-   Clube do Álbum;
-   avaliações;
-   comunidades;
-   perfis;
-   jogos;
-   rankings.

Porém, se as páginas mostrarem principalmente:

-   nome;
-   posição;
-   capa;
-   pontuação;
-   quantidade;
-   tabela;
-   ranking;

o site pode ser interpretado como uma ferramenta ou banco de dados com
pouca camada editorial.

O objetivo deve ser transformar os dados exclusivos do ChartFM em
contexto original e útil.

------------------------------------------------------------------------

# 3. Prioridade 1 --- Corrigir indexação

## Problema

O `robots.txt` permite rastreamento geral:

``` text
User-agent: *
Allow: /

Sitemap: https://chartfm.com.br/sitemap.xml
```

Permitir rastreamento geral não é necessariamente um erro, mas páginas
utilitárias, privadas ou sem valor de busca precisam ser analisadas
individualmente.

Páginas como as seguintes não deveriam ser candidatas normais à
indexação:

``` text
/login
/signup
/forgot-password
/reset-password
/verify-email
/settings
/notifications
/onboarding
/chart/setup
/*/edit
/community/create
/community/*/settings
```

Também devem ser analisadas:

-   páginas privadas;
-   páginas que dependem de autenticação;
-   telas de configuração;
-   telas de edição;
-   páginas vazias;
-   páginas com conteúdo insuficiente;
-   filtros e combinações de query strings;
-   páginas duplicadas;
-   estados intermediários de fluxos.

## Solução

### Passo 1

Criar uma lista completa das rotas do projeto.

Separar em:

-   pública e indexável;
-   pública, mas `noindex`;
-   privada;
-   administrativa;
-   utilitária;
-   duplicada ou canônica.

### Passo 2

Adicionar `noindex, nofollow` ou `noindex, follow`, conforme o caso, nas
páginas que não devem aparecer nos mecanismos de busca.

Exemplo conceitual no Next.js:

``` ts
export const metadata = {
  robots: {
    index: false,
    follow: false,
  },
};
```

Para páginas públicas auxiliares, pode ser melhor:

``` ts
export const metadata = {
  robots: {
    index: false,
    follow: true,
  },
};
```

### Passo 3

Garantir que páginas administrativas e privadas não dependam apenas de
`robots.txt`.

O acesso deve continuar protegido por autenticação e autorização.

### Passo 4

Revisar canonical URLs.

Páginas com parâmetros, filtros ou versões equivalentes devem apontar
para uma URL canônica quando necessário.

### Resultado esperado

O Google deve encontrar principalmente páginas que representam o melhor
do ChartFM, e não telas técnicas ou utilitárias.

------------------------------------------------------------------------

# 4. Prioridade 2 --- Reconstruir o sitemap

## Problema

O sitemap atual representa apenas uma parte pequena do conteúdo público
real do ChartFM.

O projeto possui páginas potencialmente valiosas de:

-   artistas;
-   álbuns;
-   músicas;
-   charts públicos;
-   comunidades;
-   gêneros;
-   perfis públicos;
-   histórico do Global 100;
-   Push;
-   Copa;
-   Editorial;
-   Guides.

## Solução recomendada

Criar um sitemap principal e sitemaps segmentados.

Estrutura sugerida:

``` text
/sitemap.xml

/sitemaps/static.xml
/sitemaps/artists.xml
/sitemaps/albums.xml
/sitemaps/songs.xml
/sitemaps/charts.xml
/sitemaps/communities.xml
/sitemaps/editorial.xml
/sitemaps/guides.xml
```

## Critérios mínimos de indexação

Não incluir automaticamente todas as entidades do banco.

### Artista indexável

Exemplo de critérios:

-   possui músicas cadastradas;
-   possui atividade em charts;
-   possui avaliações relacionadas;
-   possui conteúdo suficiente para preencher a página.

### Álbum indexável

Exemplo:

-   possui avaliações;
-   possui nota;
-   possui descrição contextual;
-   possui atividade relevante;
-   pertence a artista com página válida.

### Música indexável

Exemplo:

-   apareceu em algum chart;
-   possui histórico;
-   possui atividade da comunidade;
-   possui contexto suficiente.

### Chart pessoal indexável

Considerar apenas se:

-   for público;
-   possuir conteúdo;
-   tiver histórico mínimo;
-   não for uma página vazia ou recém-criada sem dados.

## Resultado esperado

O sitemap deve representar as melhores páginas públicas do projeto, sem
inflar artificialmente o número de URLs.

------------------------------------------------------------------------

# 5. Prioridade 3 --- Fortalecer páginas programáticas

O ChartFM já possui funções como:

``` text
buildSongContext()
buildArtistContext()
buildAlbumContext()
buildChartContext()
buildCommunityContext()
```

Essa direção é boa e deve ser expandida.

O objetivo é evitar páginas que sejam apenas uma coleção de números.

------------------------------------------------------------------------

# 6. Página de artista

## Situação

As páginas possuem bons dados, mas ainda podem parecer excessivamente
orientadas a métricas.

## Adicionar

### Resumo contextual

Exemplo:

> Artista X tem 24 músicas registradas no ChartFM. Sua música mais bem
> colocada é Y, que chegou ao #2 do Global 100. Nesta semana, quatro
> músicas aparecem nas paradas da comunidade.

### Desempenho recente

Criar uma seção como:

## Desempenho recente no ChartFM

Exemplo:

> Nas últimas quatro semanas, o artista ganhou espaço nas paradas da
> comunidade. A música X entrou no Top 10 enquanto Y apresentou
> crescimento nas paradas pessoais.

O texto deve ser derivado de dados reais.

### Músicas mais populares entre os usuários

Não mostrar apenas a lista.

Adicionar interpretação:

-   música com maior pico;
-   música com maior permanência;
-   música em crescimento;
-   música mais presente nos charts pessoais.

### Histórico no Global 100

Mostrar:

-   maior pico;
-   número de entradas;
-   semanas acumuladas;
-   Top 10;
-   #1, quando houver;
-   melhor estreia.

### Descoberta interna

Adicionar links para:

-   músicas;
-   álbuns;
-   charts relacionados;
-   avaliações;
-   comunidades relacionadas, quando fizer sentido.

------------------------------------------------------------------------

# 7. Página de música

## Problema

Uma página de música pode parecer pobre se mostrar apenas:

-   capa;
-   artista;
-   posição;
-   pontos;
-   histórico.

## Adicionar

### Contexto da música no ChartFM

Exemplo:

> X estreou no Global 100 na posição #18 e atingiu seu pico de #4 três
> semanas depois. Atualmente, aparece em 14 paradas pessoais públicas.

### Trajetória

Gerar texto com base em:

-   estreia;
-   pico;
-   semanas;
-   tendência;
-   retorno;
-   queda;
-   crescimento.

### Desempenho recente

Comparar:

-   semana atual;
-   semana anterior;
-   últimas quatro semanas.

### Relações internas

Adicionar:

-   outras músicas do artista;
-   álbum relacionado;
-   charts onde aparece;
-   usuários ou charts públicos relacionados, respeitando privacidade;
-   conteúdo editorial relacionado.

------------------------------------------------------------------------

# 8. Página de álbum

## Problema

Páginas de álbum precisam ir além de capa, nota e lista de avaliações.

## Adicionar

### Resumo da recepção no ChartFM

Exemplo:

> O álbum possui nota média de 8,4 entre os usuários do ChartFM. As
> avaliações mostram recepção predominantemente positiva, com destaque
> para as faixas X e Y entre os charts da comunidade.

Somente gerar afirmações que possam ser comprovadas pelos dados.

### Distribuição das notas

Mostrar:

-   média;
-   mediana;
-   distribuição;
-   evolução da nota;
-   comparação temporal.

### Destaques do álbum

Se os dados permitirem:

-   música mais presente em charts;
-   maior pico;
-   faixa com maior crescimento;
-   faixa mais recorrente.

### Avaliações da comunidade

Valorizar reviews com conteúdo textual.

Evitar páginas compostas apenas por estrelas e números.

### Links internos

Adicionar:

-   artista;
-   músicas;
-   charts;
-   Clube do Álbum;
-   editorial relacionado.

------------------------------------------------------------------------

# 9. Prioridade 4 --- Expandir o Editorial

## Situação

O ChartFM já possui estrutura editorial, mas ela precisa crescer e se
tornar uma demonstração clara de conteúdo original.

## Direção recomendada

O diferencial do ChartFM é possuir dados próprios.

O editorial deve explorar esses dados.

## Ideias de conteúdo

### Semanal

-   5 músicas que mais cresceram no ChartFM esta semana;
-   maiores estreias da semana;
-   mudanças no Top 10;
-   quem ganhou e perdeu força;
-   artistas com maior crescimento;
-   destaques da Airplay Chart;
-   destaques da Albums Chart.

### Mensal

-   artistas que mais ganharam ouvintes;
-   maiores músicas do mês;
-   álbuns mais bem avaliados;
-   maiores descobertas do Push;
-   comunidades mais ativas;
-   retrospectiva dos jogos.

### Histórico

-   maiores estreias da história do Global 100;
-   músicas com mais semanas em #1;
-   artistas com mais entradas;
-   maiores subidas;
-   maiores quedas;
-   retornos históricos;
-   recordes.

### Conteúdo sobre a comunidade

-   álbuns que dividiram opiniões;
-   artistas em crescimento;
-   descobertas do Push que chegaram ao Global 100;
-   músicas que começaram pequenas e cresceram;
-   diferenças entre Airplay e charts pessoais.

## Regra fundamental

Não inventar contexto.

Todo conteúdo deve ser:

-   baseado em dados reais;
-   calculável;
-   verificável;
-   atualizado corretamente.

------------------------------------------------------------------------

# 10. Prioridade 5 --- Revisar afirmações editoriais

## Problema

Textos estáticos com afirmações quantitativas podem prejudicar a
confiança caso não correspondam aos dados reais.

Exemplos de risco:

-   afirmar que existem milhares de charts se isso não for verdade;
-   mencionar dezenas ou centenas de avaliações sem dados;
-   afirmar tendências da comunidade sem cálculo real;
-   apresentar comportamento coletivo sem base estatística.

## Solução

### Opção A --- Dados dinâmicos

Buscar os valores diretamente do banco.

Exemplo:

``` text
Nesta semana, 327 charts públicos participaram da formação do ranking.
```

### Opção B --- Texto neutro

Quando não for necessário mostrar números:

``` text
O ranking é formado a partir das paradas pessoais publicadas pela comunidade.
```

### Regra

Nunca usar números promocionais estimados ou inflados.

------------------------------------------------------------------------

# 11. Prioridade 6 --- Melhorar os guias

## Situação

Os guias são uma das áreas mais fortes do ChartFM.

Existem conteúdos sobre:

-   criação de parada;
-   avaliação de álbuns;
-   descoberta musical;
-   Copa;
-   sistema de pontuação;
-   Global 100;
-   importação de histórico;
-   comunidades;
-   glossário.

## Melhorias

### Links internos contextuais

Exemplo:

No guia sobre Global 100:

-   link para o ranking atual;
-   link para histórico;
-   link para metodologia;
-   link para criar um chart.

### Leia também

Adicionar ao final:

## Leia também

-   Como criar sua parada semanal;
-   Como funciona a pontuação;
-   Como o Global 100 é calculado.

### Atualização

Mostrar:

-   data de publicação;
-   data de atualização, quando aplicável.

### Autoria

Adicionar informação clara sobre autoria ou equipe editorial do ChartFM.

------------------------------------------------------------------------

# 12. Prioridade 7 --- Auditar a experiência sem login

Antes de solicitar nova análise, navegar pelo site:

-   em aba anônima;
-   sem cookies;
-   sem conta;
-   em desktop;
-   em celular.

## Verificar

-   Home possui conteúdo suficiente?
-   O visitante entende o que é ChartFM?
-   Existem páginas públicas acessíveis?
-   Os rankings abrem sem login?
-   Artistas, músicas e álbuns possuem contexto?
-   Guides são fáceis de encontrar?
-   Editorial é fácil de encontrar?
-   Existem links internos?
-   O site parece vivo?
-   Há páginas vazias?
-   Existem erros?
-   Existem skeletons infinitos?
-   Há CTAs excessivos para login?
-   O conteúdo principal está escondido?

## Objetivo

Um visitante sem conta deve conseguir passar vários minutos explorando
conteúdo útil.

------------------------------------------------------------------------

# 13. Prioridade 8 --- Fortalecer a Home

A Home deve explicar rapidamente:

1.  o que é o ChartFM;
2.  o que o visitante pode fazer;
3.  o que está acontecendo agora;
4.  quais conteúdos pode explorar sem login;
5.  por que o projeto é diferente.

## Estrutura sugerida

### Hero

Mensagem clara:

> Crie sua própria parada musical e descubra o que a comunidade está
> ouvindo.

CTAs:

-   Criar meu chart;
-   Explorar rankings.

### O que está acontecendo

Mostrar conteúdo real:

-   líder da Global 100;
-   líder da Airplay;
-   álbum em destaque;
-   votação aberta;
-   evento ativo.

### Descubra

Mostrar:

-   artistas em crescimento;
-   músicas em alta;
-   álbuns avaliados;
-   Push.

### Conteúdo editorial

Mostrar artigos recentes.

### Como funciona

Explicar brevemente:

-   chart pessoal;
-   agregação;
-   Global 100;
-   comunidade.

------------------------------------------------------------------------

# 14. Prioridade 9 --- Melhorar navegação interna

Cada página deve levar naturalmente a outras páginas.

## Artista

Linkar para:

-   músicas;
-   álbuns;
-   charts;
-   editorial.

## Música

Linkar para:

-   artista;
-   álbum;
-   histórico;
-   rankings;
-   músicas relacionadas.

## Álbum

Linkar para:

-   artista;
-   músicas;
-   avaliações;
-   Clube do Álbum;
-   editorial.

## Global 100

Linkar para:

-   páginas das músicas;
-   artistas;
-   histórico;
-   metodologia;
-   artigos da semana.

## Editorial

Linkar para entidades citadas.

O objetivo é criar uma rede real de conteúdo.

------------------------------------------------------------------------

# 15. Prioridade 10 --- Evitar páginas fracas em escala

Sites com conteúdo programático precisam controlar qualidade.

## Não indexar automaticamente

-   artista sem atividade;
-   música sem dados;
-   álbum sem avaliações e sem contexto;
-   chart vazio;
-   comunidade abandonada e sem conteúdo;
-   perfil vazio;
-   filtros sem valor;
-   paginações vazias.

## Criar critérios de qualidade

Antes de uma página ser indexável, verificar se possui conteúdo mínimo.

Exemplo conceitual:

``` text
INDEXÁVEL SE:

tem contexto textual
E
tem dados relevantes
E
tem links internos
E
não está vazia
E
não é duplicada
```

------------------------------------------------------------------------

# 16. Ordem de execução recomendada

## Fase 1 --- Correções críticas

Fazer antes de qualquer nova solicitação ao AdSense:

1.  mapear todas as rotas;
2.  definir páginas indexáveis;
3.  aplicar `noindex` onde necessário;
4.  revisar canonicals;
5.  reconstruir sitemap;
6.  remover páginas vazias do universo indexável;
7.  revisar textos com números ou afirmações não verificáveis;
8.  testar navegação sem login.

## Fase 2 --- Conteúdo das entidades

9.  fortalecer página de artista;
10. fortalecer página de música;
11. fortalecer página de álbum;
12. adicionar contexto dinâmico;
13. adicionar histórico;
14. adicionar interpretação baseada em dados;
15. melhorar links internos.

## Fase 3 --- Editorial

16. criar calendário editorial;
17. publicar análises semanais;
18. publicar retrospectivas mensais;
19. criar páginas de recordes;
20. usar dados próprios do ChartFM;
21. conectar Editorial aos rankings e entidades.

## Fase 4 --- Home e descoberta

22. revisar Home;
23. destacar conteúdo atual;
24. mostrar atividade da comunidade;
25. melhorar Discover;
26. criar caminhos claros de navegação.

## Fase 5 --- Validação

27. testar em aba anônima;
28. testar mobile;
29. procurar páginas vazias;
30. procurar erros 404 e 500;
31. revisar títulos e descriptions;
32. revisar sitemap;
33. revisar Search Console;
34. verificar indexação;
35. garantir que conteúdo novo esteja acessível por links internos.

## Fase 6 --- Nova solicitação

Somente depois:

36. aguardar rastreamento das mudanças;
37. confirmar que páginas importantes foram descobertas;
38. confirmar que páginas fracas foram removidas do índice ou marcadas
    corretamente;
39. garantir consistência editorial;
40. solicitar nova análise do AdSense.

------------------------------------------------------------------------

# 17. Checklist antes de reaplicar

## Técnico

-   [ ] Sitemap atualizado;
-   [ ] páginas utilitárias com `noindex`;
-   [ ] páginas privadas protegidas;
-   [ ] canonicals revisados;
-   [ ] sem páginas vazias indexáveis;
-   [ ] sem erros frequentes;
-   [ ] mobile funcionando corretamente;
-   [ ] HTTPS funcionando;
-   [ ] navegação clara;
-   [ ] links internos funcionando.

## Conteúdo

-   [ ] páginas de artista com contexto;
-   [ ] páginas de música com trajetória;
-   [ ] páginas de álbum com recepção da comunidade;
-   [ ] Global 100 com contexto editorial;
-   [ ] Airplay com explicação e análise;
-   [ ] Albums Chart com contexto;
-   [ ] Guides acessíveis;
-   [ ] Editorial ativo;
-   [ ] conteúdo baseado em dados reais;
-   [ ] nenhuma estatística inventada.

## Institucional

-   [ ] Sobre;
-   [ ] Contato;
-   [ ] Política de Privacidade;
-   [ ] Termos de Uso;
-   [ ] metodologia dos rankings;
-   [ ] explicação clara do funcionamento do site.

## Experiência sem login

-   [ ] visitante entende o projeto;
-   [ ] consegue explorar rankings;
-   [ ] consegue ler guias;
-   [ ] consegue ler editorial;
-   [ ] consegue abrir artistas;
-   [ ] consegue abrir músicas;
-   [ ] consegue abrir álbuns;
-   [ ] encontra conteúdo relacionado;
-   [ ] não encontra becos sem saída.

------------------------------------------------------------------------

# 18. Recomendação estratégica final

O ChartFM não precisa virar um portal de notícias genérico.

O melhor caminho é usar o que o projeto já possui de mais valioso:

-   charts criados por usuários;
-   histórico próprio;
-   avaliações;
-   comportamento agregado;
-   Global 100;
-   Airplay;
-   Albums Chart;
-   Push;
-   Copa;
-   Clube do Álbum;
-   comunidades.

Esses dados devem gerar conteúdo que outros sites não conseguem
reproduzir facilmente.

A estratégia editorial deve seguir:

> **O ChartFM coleta atividade musical da comunidade, transforma essa
> atividade em rankings e usa os próprios dados para explicar
> tendências, descobertas e mudanças.**

Essa é uma proposta muito mais forte do que apenas adicionar textos
genéricos para aumentar a quantidade de palavras.

------------------------------------------------------------------------

# 19. Resumo de prioridades

## Crítico

1.  indexação;
2.  sitemap;
3.  páginas vazias;
4.  afirmações não verificáveis;
5.  experiência pública sem login.

## Alta prioridade

6.  páginas de artistas;
7.  páginas de músicas;
8.  páginas de álbuns;
9.  Editorial;
10. Home;
11. navegação interna.

## Evolução

12. recordes históricos;
13. artigos automáticos baseados em dados;
14. retrospectivas;
15. análises semanais;
16. páginas de tendências;
17. métricas de descoberta.

------------------------------------------------------------------------

# 20. Próxima auditoria recomendada

Após executar as correções críticas, realizar uma auditoria individual
das seguintes áreas:

1.  Home;
2.  Discover;
3.  Global 100;
4.  Airplay;
5.  Albums Chart;
6.  página de artista;
7.  página de música;
8.  página de álbum;
9.  CriticsFM;
10. Push;
11. Copa ChartFM;
12. Clube do Álbum;
13. Communities;
14. Guides;
15. Editorial.

Para cada página, avaliar:

-   conteúdo visível;
-   profundidade;
-   originalidade;
-   SEO;
-   indexação;
-   links internos;
-   experiência sem login;
-   conteúdo repetitivo;
-   oportunidade editorial;
-   CTA;
-   risco de ser percebida como conteúdo de baixo valor.

O objetivo final é fazer com que o valor real do ChartFM, que já existe
como produto e comunidade, fique igualmente claro para visitantes,
mecanismos de busca e sistemas de análise de monetização.
